"""features/store.py — FeatureStore: persist computed features to Parquet."""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Optional
import numpy as np
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq

log = logging.getLogger(__name__)

class FeatureStore:
    def __init__(self, root: str = "data/features/"):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def save(self, features: dict[str, pd.DataFrame], compression: str = "snappy") -> None:
        for name, df in features.items():
            self._save_one(name, df, compression)
        log.info("Saved %d features to %s", len(features), self.root)

    def _save_one(self, name: str, df: pd.DataFrame, compression: str = "snappy") -> None:
        feat_root = self.root / name
        feat_root.mkdir(parents=True, exist_ok=True)
        # Ensure index/columns are named so stack produces correct column names
        df = df.copy()
        df.index.name   = "timestamp"
        df.columns.name = "ticker"
        long = df.stack(future_stack=True).reset_index(name='value')
        long["timestamp"] = pd.to_datetime(long["timestamp"])
        if long["timestamp"].dt.tz is None:
            long["timestamp"] = long["timestamp"].dt.tz_localize("America/New_York")
        long["value"] = long["value"].astype(np.float32)
        for year, part in long.groupby(long["timestamp"].dt.year):
            part_dir = feat_root / f"year={year}"
            part_dir.mkdir(parents=True, exist_ok=True)
            schema = pa.schema([
                pa.field("timestamp", pa.timestamp("us", tz="America/New_York")),
                pa.field("ticker",    pa.string()),
                pa.field("value",     pa.float32()),
            ])
            table = pa.Table.from_pandas(
                part[["timestamp","ticker","value"]], schema=schema, preserve_index=False)
            pq.write_table(table, part_dir/"data.parquet", compression=compression)

    def load(self, feature_names: Optional[list[str]] = None,
             tickers: Optional[list[str]] = None,
             start_date: Optional[str] = None,
             end_date: Optional[str] = None) -> dict[str, pd.DataFrame]:
        available = self.list_features()
        if not available:
            raise FileNotFoundError(f"No features in {self.root}. Run save() first.")
        names = [n for n in (feature_names or available) if n in available]
        features = {}
        for name in names:
            df = self._load_one(name, tickers, start_date, end_date)
            if df is not None:
                features[name] = df
        log.info("Loaded %d features from %s", len(features), self.root)
        return features

    def _load_one(self, name: str, tickers, start_date, end_date) -> Optional[pd.DataFrame]:
        feat_root = self.root / name
        if not feat_root.exists():
            return None
        filters = [("ticker","in",tickers)] if tickers else None
        dataset = pq.ParquetDataset(feat_root, filters=filters)
        long = dataset.read().to_pandas()
        if long.empty:
            return None
        long["timestamp"] = pd.to_datetime(long["timestamp"]).dt.tz_convert("America/New_York")
        if start_date:
            long = long[long["timestamp"] >= pd.Timestamp(start_date, tz="America/New_York")]
        if end_date:
            long = long[long["timestamp"] <= pd.Timestamp(end_date+" 23:59:59", tz="America/New_York")]
        if long.empty:
            return None
        wide = long.pivot_table(index="timestamp", columns="ticker", values="value", aggfunc="last")
        return wide.astype(np.float64)

    def list_features(self) -> list[str]:
        return sorted([p.name for p in self.root.iterdir() if p.is_dir()])

    def feature_info(self) -> pd.DataFrame:
        rows = []
        for name in self.list_features():
            files = list((self.root/name).rglob("*.parquet"))
            size  = sum(f.stat().st_size for f in files)/1024/1024
            rows.append({"feature": name, "n_files": len(files), "size_mb": round(size,2)})
        return pd.DataFrame(rows).set_index("feature") if rows else pd.DataFrame()
